import axios from 'axios';
import { getInitData } from '@utils/telegram';

const API_URL = import.meta.env.VITE_API_URL || '';

export { API_URL };

export const api = axios.create({
  baseURL: API_URL,
});

api.interceptors.request.use((config) => {
  const token = localStorage.getItem('token');
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  const initData = getInitData();
  if (initData) {
    config.headers['x-telegram-init-data'] = initData;
  }
  return config;
});

api.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error?.response?.status === 401) {
      console.warn('[api] 401 on', error?.config?.method?.toUpperCase(), error?.config?.url, {
        hasToken: !!localStorage.getItem('token'),
        hasInitData: !!(error?.config?.headers?.['x-telegram-init-data'] || error?.config?.headers?.['X-Telegram-Init-Data']),
      });
    }
    return Promise.reject(error);
  }
);

export type ObjectType = {
  id: string;
  title: string;
  type: string;
  price: number;
  yieldPercent: number;
  location: string;
  city?: string;
  area: number;
  roi?: number;
  image?: string;
  description?: string;
  createdAt: string;
  updatedAt: string;
};

export type CommercialOffer = {
  id: string;
  objectId: string;
  content: unknown;
};

export type LeadPayload = {
  objectId: string;
  name: string;
  phone: string;
  comment?: string;
};
