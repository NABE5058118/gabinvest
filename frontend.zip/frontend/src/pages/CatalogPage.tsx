import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Heart, MapPin, LayoutGrid, TrendingUp, TrendingDown, Minus } from 'lucide-react';
import { useFavorites } from '@context/FavoritesContext';
import { useObjects } from '@utils/useObjects';
import CatalogHeader from '@components/CatalogHeader';
import CatalogFilters, { type Filters } from '@components/CatalogFilters';
import styles from '@styles/CatalogPage.module.css';

type SortOption = 'createdAt' | 'price' | 'area' | 'yieldPercent' | 'leaseEndDate';

export default function CatalogPage() {
  const navigate = useNavigate();
  const { favoriteIds, toggleFavorite } = useFavorites();
  const [showFilters, setShowFilters] = useState(false);
  const [filters, setFilters] = useState<Filters>({
    types: [],
    minPrice: '',
    maxPrice: '',
    minArea: '',
    maxArea: '',
    city: '',
    anchorTenant: '',
    sortBy: 'createdAt' as SortOption,
    sortOrder: 'desc' as 'asc' | 'desc',
    minYield: '',
    maxYield: '',
    leaseEndBefore: '',
    leaseEndAfter: '',
  });
  const [lastRotation, setLastRotation] = useState<string | null>(null);
  const { objects, loading, error, refetch } = useObjects(filters);

  useEffect(() => {
    const interval = setInterval(() => {
      refetch();
      setLastRotation(new Date().toLocaleTimeString('ru-RU'));
    }, 10 * 60 * 1000);
    return () => clearInterval(interval);
  }, [refetch]);

  if (loading) {
    return (
      <main className={styles.page}>
        <CatalogHeader
          styles={styles}
          refetch={refetch}
          setShowFilters={setShowFilters}
          lastRotation={lastRotation}
          loading={loading}
        />
        <div className={styles.list}>
          {Array.from({ length: 6 }).map((_, idx) => (
            <div key={idx} className={styles.skeletonCard}>
              <div className={styles.skeletonImage} />
              <div className={styles.skeletonBody}>
                <div className={`${styles.skeletonLine} ${styles.skeletonLineShort}`} />
                <div className={styles.skeletonLine} />
                <div className={`${styles.skeletonLine} ${styles.skeletonLineShort}`} />
              </div>
            </div>
          ))}
        </div>
      </main>
    );
  }

  if (error) {
    return (
      <div className={styles.page}>
        <div className={styles.error}>{error}</div>
      </div>
    );
  }

  const sortedObjects = objects;

  const resetFilters = () => {
    const reset = {
      types: [], minPrice: '', maxPrice: '', minArea: '', maxArea: '', city: '', anchorTenant: '',
      sortBy: 'createdAt' as SortOption, sortOrder: 'desc' as 'asc' | 'desc', minYield: '', maxYield: '',
      leaseEndBefore: '', leaseEndAfter: '',
    };
    setFilters(reset);
  };

  const typeLabels: Record<string, string> = {
    'Офис': 'Офис',
    'Склад': 'Склад',
    'Торговое помещение': 'Торговое помещение',
    'Другое': 'Другое',
  };

  const priceIndicatorLabels: Record<string, { label: string; icon: typeof TrendingUp }> = {
    'above_market': { label: 'Выше рынка', icon: TrendingUp },
    'market': { label: 'По рынку', icon: Minus },
    'below_market': { label: 'Ниже рынка', icon: TrendingDown },
  };

  return (
    <main className={styles.page}>
      <CatalogHeader
        styles={styles}
        refetch={refetch}
        setShowFilters={setShowFilters}
        lastRotation={lastRotation}
        loading={loading}
      />

<CatalogFilters
        styles={styles}
        filters={filters}
        setFilters={setFilters}
        showFilters={showFilters}
        setShowFilters={setShowFilters}
        resetFilters={resetFilters}
      />

      <div className={styles.list}>
        {sortedObjects.length === 0 ? (
          <div className={styles.empty}>
            <div className={styles.emptyIcon}>
              <LayoutGrid size={64} strokeWidth={1} color="#ccc" />
            </div>
            <p className={styles.emptyText}>Объекты не найдены</p>
            <button className={styles.emptyBtn} onClick={resetFilters}>
              Сбросить фильтры
            </button>
          </div>
        ) : (
          sortedObjects.map((obj, idx) => (
            <div
              key={obj.id}
              className={styles.card}
              onClick={() => navigate(`/objects/${obj.id}`)}
              onKeyDown={(e) => {
                if (e.key === 'Enter' || e.key === ' ') {
                  if ((e.target as HTMLElement).closest('button')) return;
                  e.preventDefault();
                  navigate(`/objects/${obj.id}`);
                }
              }}
              tabIndex={0}
              role="link"
            >
              <div className={styles.cardImage}>
                {obj.images && obj.images.length > 0 ? (
                  <img
                    src={obj.images[0].url}
                    alt={obj.title}
                    className={styles.cardImg}
                    {...(idx === 0 ? { fetchpriority: 'high' } : { loading: 'lazy' })}
                    decoding="async"
                    onError={(e) => {
                      (e.target as HTMLImageElement).style.display = 'none';
                    }}
                  />
                ) : obj.image ? (
                  <img
                    src={obj.image}
                    alt={obj.title}
                    className={styles.cardImg}
                    {...(idx === 0 ? { fetchpriority: 'high' } : { loading: 'lazy' })}
                    decoding="async"
                    onError={(e) => {
                      (e.target as HTMLImageElement).style.display = 'none';
                    }}
                  />
                ) : (
                  <div className={styles.placeholder}>
                    <LayoutGrid size={48} strokeWidth={1} color="#ccc" />
                  </div>
                )}
                <span className={styles.typeBadge}>{typeLabels[obj.type] || obj.type}</span>
                {obj.priceIndicator && priceIndicatorLabels[obj.priceIndicator] && (
                  <span className={`${styles.priceIndicatorBadge} ${styles[obj.priceIndicator]}`}>
                    {(() => {
                      const Icon = priceIndicatorLabels[obj.priceIndicator].icon;
                      return <Icon size={12} strokeWidth={2} />;
                    })()}
                    {priceIndicatorLabels[obj.priceIndicator].label}
                  </span>
                )}
                <button
                  key={obj.id}
                  type="button"
                  className={styles.favoriteBtn}
                  onClick={(e) => {
                    e.stopPropagation();
                    toggleFavorite(obj.id);
                  }}
                  aria-label={favoriteIds.has(obj.id) ? 'Убрать из избранного' : 'Добавить в избранное'}
                >
                  <Heart
                    size={20}
                    strokeWidth={2}
                    fill={favoriteIds.has(obj.id) ? '#ff0000' : 'none'}
                  />
                </button>
              </div>
              <div className={styles.cardBody}>
                <h3 className={styles.cardTitle}>{obj.title}</h3>
                <p className={styles.cardLocation}>
                  <MapPin size={12} strokeWidth={2} />
                  {obj.location}
                </p>
                <div className={styles.cardFooter}>
                  <span className={styles.price}>{obj.price.toLocaleString('ru-RU')} ₽</span>
                  <span className={styles.yield}>Доходность: {obj.yieldPercent}%</span>
                </div>
                {obj.anchorTenantName && (
                  <div className={styles.anchorTenant}>
                    Якорный арендатор: {obj.anchorTenantName}
                  </div>
                )}
              </div>
            </div>
          ))
        )}
      </div>
    </main>
  );
}
