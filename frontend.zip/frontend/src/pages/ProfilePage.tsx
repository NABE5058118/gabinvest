import { User, ChevronRight, Settings, LogOut, FileText } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@context/AuthContext';
import styles from '@styles/ProfilePage.module.css';

export default function ProfilePage() {
  const navigate = useNavigate();
  const { user, logout } = useAuth();

  const displayName = [user?.firstName, user?.lastName].filter(Boolean).join(' ') || 'Пользователь';
  const displayUsername = user?.username ? `@${user.username}` : '';

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  return (
    <div className={styles.page}>
      <header className={'header'}>
        <h1 className={styles.title}>Профиль</h1>
      </header>

      <div className={styles.content}>
        <div className={styles.profileCard}>
          <div className={styles.avatar}>
            <User size={32} strokeWidth={1.5} color="#999" />
          </div>
          <div className={styles.profileInfo}>
            <div className={styles.profileName}>{displayName}</div>
            {displayUsername && <div className={styles.profilePhone}>{displayUsername}</div>}
          </div>
        </div>

        <div className={styles.menu}>
          <button className={styles.menuItem} onClick={() => navigate('/profile/edit')}>
            <div className={styles.menuItemLeft}>
              <Settings size={20} strokeWidth={2} />
              <span>Настройки</span>
            </div>
            <ChevronRight size={20} strokeWidth={2} className={styles.menuItemRight} />
          </button>
          <button className={styles.menuItem} onClick={() => navigate('/profile/leads')}>
            <div className={styles.menuItemLeft}>
              <FileText size={20} strokeWidth={2} />
              <span>Мои заявки</span>
            </div>
            <ChevronRight size={20} strokeWidth={2} className={styles.menuItemRight} />
          </button>
          <button className={styles.menuItem} onClick={handleLogout}>
            <div className={styles.menuItemLeft}>
              <LogOut size={20} strokeWidth={2} />
              <span>Выход</span>
            </div>
            <ChevronRight size={20} strokeWidth={2} className={styles.menuItemRight} />
          </button>
        </div>
      </div>
    </div>
  );
}
