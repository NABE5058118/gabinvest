import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Plus, Trash2, Upload } from 'lucide-react';
import { adminApi } from '@utils/adminApi';
import { normalizeOfferFileName } from '@utils/filename';
import ConfirmModal from '@components/ConfirmModal';
import styles from '@styles/AdminObjects.module.css';

type ObjectItem = {
  id: string;
  title: string;
  type: string;
  price: number;
  yieldPercent: number;
  location: string;
  city?: string;
  area: number;
  roi?: number;
  description?: string;
  offerFileUrl?: string;
  offerFileName?: string;
  image?: string;
  images?: Array<{ id: string; url: string; sort: number }>;
};

export default function AdminObjectsPage() {
  const [items, setItems] = useState<ObjectItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [toast, setToast] = useState<{ type: 'success' | 'error'; message: string } | null>(null);
  const [deleteTarget, setDeleteTarget] = useState<string | null>(null);
  const [deleteLoading, setDeleteLoading] = useState(false);
  const navigate = useNavigate();

  const fetchItems = async () => {
    try {
      setLoading(true);
      const all: ObjectItem[] = [];
      for (let page = 1; page <= 10000; page += 1) {
        const { data } = await adminApi.get('/api/admin/objects', { params: { page, limit: 50 } });
        all.push(...data);
        if (data.length < 50) break;
      }
      setItems(all);
    } catch {
      setError('Ошибка загрузки');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    // eslint-disable-next-line react-hooks/set-state-in-effect
    fetchItems();
  }, []);

  const requestDelete = (id: string) => {
    setDeleteTarget(id);
  };

  const confirmDelete = async () => {
    if (!deleteTarget) return;
    const id = deleteTarget;
    setDeleteTarget(null);
    setDeleteLoading(true);
    try {
      await adminApi.delete(`/api/admin/objects/${id}`);
      setItems((prev) => prev.filter((i) => i.id !== id));
      setToast({ type: 'success', message: 'Объект удалён' });
      window.dispatchEvent(new Event('objects:refresh'));
    } catch {
      setError('Ошибка удаления');
      setToast({ type: 'error', message: 'Ошибка удаления' });
    } finally {
      setDeleteLoading(false);
    }
  };

  return (
    <div className={styles.page}>
      <header className={'header'}>
        <h1 className={styles.title}>Объекты</h1>
      </header>

      <div className={styles.content}>
        <button className={styles.addBtn} onClick={() => navigate('/admin/objects/new')}>
          <Plus size={20} strokeWidth={2} style={{ marginRight: 8 }} />
          Добавить объект
        </button>

        {loading && <div className={styles.empty}>Загрузка...</div>}
        {error && <div className={styles.empty}>{error}</div>}
        {toast && (
          <div className={toast.type === 'success' ? styles.toastSuccess : styles.toastError} role="status" aria-live="polite">
            {toast.message}
          </div>
        )}
        {!loading && !error && items.length === 0 && (
          <div className={styles.empty}>Нет объектов</div>
        )}
        {items.map((item) => (
          <div key={item.id} className={styles.item}>
            <div className={styles.itemHeader}>
              <div className={styles.itemTitle}>{item.title}</div>
            </div>
            <div className={styles.itemMeta}>
              {item.type} • {item.location} • {item.price.toLocaleString('ru-RU')} ₽
            </div>
            {item.city && <div className={styles.itemMeta}>{item.city}</div>}
            <div className={styles.itemMeta}>
              Площадь: {item.area} м² • Доходность: {item.yieldPercent}%
            </div>
        {item.offerFileName && (
          <div className={styles.itemMeta}>КП: {normalizeOfferFileName(item.offerFileName)}</div>
        )}
        <div className={styles.itemMeta}>
          {(item.images && item.images.length > 0 ? item.images : (item.image ? [{ id: 'legacy', url: item.image }] : [])).map((img) => (
            <img
              key={img.id}
              src={img.url}
              alt={item.title}
              className={styles.thumb}
              onError={(e) => {
                (e.target as HTMLImageElement).style.display = 'none';
              }}
            />
          ))}
        </div>
            <div className={styles.itemActions}>
              <button
                className={styles.actionBtn}
                onClick={() => navigate(`/admin/objects/${item.id}`)}
              >
                Редактировать
              </button>
              <button
                className={styles.actionBtn}
                onClick={() => navigate(`/admin/objects/${item.id}/offer`)}
              >
                <Upload size={16} strokeWidth={2} style={{ marginRight: 4 }} />
                КП
              </button>
              <button
                className={`${styles.actionBtn} ${styles.dangerAction}`}
                onClick={() => requestDelete(item.id)}
                aria-label="Удалить объект"
              >
                <Trash2 size={16} strokeWidth={2} />
              </button>
            </div>
          </div>
        ))}
      </div>

      <ConfirmModal
        open={!!deleteTarget}
        message="Вы действительно хотите удалить объект? Это действие нельзя отменить."
        confirmLabel="Удалить"
        loading={deleteLoading}
        onConfirm={confirmDelete}
        onCancel={() => setDeleteTarget(null)}
      />
    </div>
  );
}
